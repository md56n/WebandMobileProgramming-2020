function upDate(previewPic) {
    /* In this function you should
       1) change the url for the background image of the div with the id = "image"
       to the source file of the preview image

       2) Change the text  of the div with the id = "image"
       to the alt text of the preview image
       */

    //element to change scr
    var element = document.getElementById("image");
    element.style.backgroundImage = "url("+previewPic.src+")";

    //element to change alt
    element.innerHTML = previewPic.alt;
}

function unDo() {
    /* In this function you should
   1) Update the url for the background image of the div with the id = "image"
   back to the orginal-image.  You can use the css code to see what that original URL was

   2) Change the text  of the div with the id = "image"
   back to the original text.  You can use the html code to see what that original text was
   */

    //element to change scr back to original
    var element = document.getElementById("image");
    element.style.backgroundImage = "url('')";
    //element to change alt back to original
    element.innerHTML = 'Hover over an image below to display here.';
}
