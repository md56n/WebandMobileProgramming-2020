package com.example.icp13;

import android.content.Context;
import android.media.AudioManager;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.widget.Toast;

import java.util.HashMap;
import java.util.Locale;

public class Speaker implements TextToSpeech.OnInitListener {

    private TextToSpeech tts;
    private boolean ready = false;
    private boolean allowed = false;
    Context c;
    String speech;
    public Speaker(Context context) {
        tts = new TextToSpeech(context, this);
        c = context;
    }
    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            tts.setLanguage(Locale.US);
            ready = true;
            tts.speak(speech, TextToSpeech.QUEUE_ADD, null);
            speech = "";
        }
    }

    public void speak(String text) {
        Log.d("ready", Boolean.toString(ready));
        // if speaker is fully initialized before this is called
        if (ready) {
            tts.speak(text, TextToSpeech.QUEUE_ADD, null);
        }
        //if not yet, we can store the text for it to speak later.
        else {
            speech = text;
        }
    }

    public void pause(int duration) {
        tts.playSilence(duration, TextToSpeech.QUEUE_ADD, null);
    }
    public void destroy() {
        tts.shutdown();
    }
}
