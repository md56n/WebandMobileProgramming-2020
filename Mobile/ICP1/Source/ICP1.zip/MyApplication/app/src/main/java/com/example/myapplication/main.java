package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.EditText;

public class main extends AppCompatActivity {

    private TextView title;
    private EditText getUsername;
    private EditText getPassword;
    private TextView info;
    private Button login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getUsername = (EditText)findViewById(R.id.getUsername);
        getPassword = (EditText)findViewById(R.id.getPassword);
        login = (Button)findViewById(R.id.login);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validate(getUsername.getText().toString(), getPassword.getText().toString());
            }
        });
    }

    private void validate(String getUsername, String getPassword) {
        if((getUsername.equals("TheUser"))&&(getPassword.equals("Password"))) {
            Intent intent = new Intent (main.this, LoggedIn.class);
            startActivity(intent);
        } else {
            info.setText("Incorrect username and/or password");
        }
    }
}
