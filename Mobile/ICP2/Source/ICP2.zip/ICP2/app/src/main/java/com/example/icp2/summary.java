package com.example.icp2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import org.w3c.dom.Text;

public class summary extends AppCompatActivity {

    //Declare
    private Button viewOrder;
    private ListView list;
    private String orders;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_summary);

        viewOrder = (Button)findViewById(R.id.order);
        list = (ListView)findViewById(R.id.list);
        orders = MainActivity.orderSummary;

        String [] myItems = {orders};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, myItems);
        ListView list = (ListView) findViewById(R.id.list);
        list.setAdapter(adapter);

        //When backtoorder is clicked
        viewOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}