package com.example.icp2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.CheckBox;
import android.widget.NumberPicker;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    //Declare variables
    private EditText name;
    private CheckBox mushrooms;
    private boolean mushroomsTrue;
    private CheckBox pepperoni;
    private boolean pepperoniTrue;
    private CheckBox spinach;
    private boolean spinachTrue;
    private NumberPicker orderQuantity;
    private int quantityPicked;
    private Button orderShow;
    private Button summaryShow;
    private int price;
    private String named;
    private String order1;
    private String order2 = " ";
    private String order3 = " ";
    private String order4 = " ";
    private String order5;
    public static String orderSummary;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Assign variables
        orderQuantity = (NumberPicker)findViewById(R.id.number);
        orderShow = (Button)findViewById(R.id.order);
        summaryShow = (Button)findViewById(R.id.summary);

        //Set up number picker
        orderQuantity.setMinValue(1);
        orderQuantity.setMaxValue(20);
        orderQuantity.setWrapSelectorWheel(false);

        //When order is clicked
        orderShow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                name = (EditText)findViewById(R.id.getName);
                named = name.getText().toString().trim();

                //Get information from checkbox
                mushrooms = (CheckBox) findViewById(R.id.mushrooms);
                mushroomsTrue = mushrooms.isChecked();
                pepperoni = (CheckBox) findViewById(R.id.pepperoni);
                pepperoniTrue = pepperoni.isChecked();
                spinach = (CheckBox) findViewById(R.id.spinach);
                spinachTrue = spinach.isChecked();
                order1 = "Dear " + named + "\n" + "You ordered a cheese pizza ";

                //Get quantity from number picker
                quantityPicked = orderQuantity.getValue();

                //Calculate cost
                price = 10;
                if(mushroomsTrue) {
                    price += 3;
                    order2 ="with mushrooms ";
                }
                if(pepperoniTrue) {
                    price += 4;
                    order3 = "with pepperoni ";
                }
                if(spinachTrue) {
                    price += 2;
                    order4 = "with spinach ";
                }
                price *= quantityPicked;

                order5 = "\n" + "Quantity: " + Integer.toString(quantityPicked) + "\n" + "Price: $" + Integer.toString(price);

                orderSummary = order1 + order2 + order3 + order4 + order5;

                //create email
                Intent i = new Intent(android.content.Intent.ACTION_SEND);
                i.setType("plain/text");
                i.putExtra(Intent.EXTRA_EMAIL  , new String[]{"recipient@example.com"});
                i.putExtra(Intent.EXTRA_SUBJECT, "Pizza Order Summary");
                i.putExtra(Intent.EXTRA_TEXT   , orderSummary);
                startActivity(i);
            }
        });

        //When summary is clicked
        summaryShow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                name = (EditText)findViewById(R.id.getName);
                named = name.getText().toString().trim();

                //Get information from checkbox
                mushrooms = (CheckBox) findViewById(R.id.mushrooms);
                mushroomsTrue = mushrooms.isChecked();
                pepperoni = (CheckBox) findViewById(R.id.pepperoni);
                pepperoniTrue = pepperoni.isChecked();
                spinach = (CheckBox) findViewById(R.id.spinach);
                spinachTrue = spinach.isChecked();
                order1 = "Dear " + named + "\n" + "You ordered a cheese pizza";

                //Get quantity from number picker
                quantityPicked = orderQuantity.getValue();

                //Calculate cost
                price = 10;
                if(mushroomsTrue) {
                    price += 3;
                    order2 =" with mushrooms ";
                }
                if(pepperoniTrue) {
                    price += 4;
                    if(mushroomsTrue) {
                        order3 = "and pepperoni ";
                    } else order3 = "with pepperoni ";
                }
                if(spinachTrue) {
                    price += 2;
                    if((mushroomsTrue)||(pepperoniTrue)) {
                        order4 = "and spinach";
                    } else order4 = "with spinach";
                }
                price *= quantityPicked;

                order5 = "\n" + "Quantity: " + Integer.toString(quantityPicked) + "\n" + "Price: $" + Integer.toString(price);

                orderSummary = order1 + order2 + order3 + order4 + order5;

                //show summary
                startActivity(new Intent(MainActivity.this, summary.class));
            }
        });
    }
}